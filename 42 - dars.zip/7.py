def isprime(son):
    if son < 2:
        return False
    for i in range(2,son // 2 + 1):
        if not son % i: 
            return False
    return True    
sonlar = [1,2,3,4,5,6,7,8,9,11]
sonlar = list(filter(isprime,sonlar))
print(sonlar)