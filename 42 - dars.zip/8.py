obshiy = [1,23,34.5,"sdf",'sdfa','sdf',True]
strings = list(filter(lambda element: isinstance(element,str),obshiy))
print(strings)