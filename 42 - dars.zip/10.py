def tup(son):
    if isinstance(son,int):
        return float(son)
    if isinstance(son,float):
        return int(son)
sonlar = [2,2,3,4.54,34.43,23.43]
sonlar = list(map(tup,sonlar))
print(sonlar)