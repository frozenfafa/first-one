sonlar = [1,23,45,75,155,176,347,754]
try:
    n = int(input("Enter a number: "))
except:
    print("\nInvalid text !!!")  
sonlar = list(filter(lambda son: son > n ** 3, sonlar))
print(sonlar)