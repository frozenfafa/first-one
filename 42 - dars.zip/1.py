def primeprint(son):
    for i in range(2,son+1):
        count = 0
        for j in range(2, i // 2):
            if not i % j:
                count = 1
                break
        if not count == 1:
            print(i)
primeprint(100)            

