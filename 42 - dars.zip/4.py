list1 = [2,3,-5,-4]
list1 = list(map((lambda son: -son if son > 0 else son * 2), list1))
print(list1)