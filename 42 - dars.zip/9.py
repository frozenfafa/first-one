import json
sonlar = [1,2,3,-4,-53,23,-3,0]
print(list(filter(lambda son: son > 0, sonlar)))