binary = [1,0,1,0,0,0,1,1,0,1,0]
boll = list(map(lambda son: bool(son),binary))
print(boll)     
