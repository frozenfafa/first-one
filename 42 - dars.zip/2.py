from math import ceil
list1 = [1.32,4.12,54.32,43]
list1 = list(map(ceil,list1))
print(list1)