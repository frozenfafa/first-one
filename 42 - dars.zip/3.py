from math import floor
list1 = [1.32,4.12,54.32,43,-12.99]
list1 = list(map(int,list1))
print(list1)