sonlar = [1,2,3,4,3.12,34.12,43.23,12]
sonlar = list(filter(lambda son: isinstance(son,int),sonlar))
print(sonlar)